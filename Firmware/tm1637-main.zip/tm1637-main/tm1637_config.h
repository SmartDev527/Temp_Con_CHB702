#ifndef _TM1637_CONFIG_H_
#define _TM1637_CONFIG_H_

#define _TM1637_FREERTOS            0
#define _TM1637_BIT_DELAY           20

#endif
